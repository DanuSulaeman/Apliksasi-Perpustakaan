from db import DBConnection as mydb
class Kategori:
    def __init__(self):
        self.__idkategori= None
        self.__nama_kategori= None
        self.__info = None
        self.conn = None
        self.affected = None
        self.result = None
    @property
    def idkategori(self):
        return self.__idkategori
    
    @idkategori.setter
    def idkategori(self, value):
        self.__idkategori = value
    
    @property
    def nama_kategori(self):
        return self.__nama_kategori

    @nama_kategori.setter
    def nama_kategori(self, value):
        self.__nama_kategori = value
        
    def simpan(self):
        self.conn = mydb()
        val = (self.__idkategori, self.__nama_kategori)
        sql="INSERT INTO kategori (idkategori, nama_kategori) VALUES " + str(val) 
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
        
    def update(self, id):
        self.conn = mydb()
        val = (self.__nama_kategori, id)
        sql="UPDATE kategori SET nama_kategori=%s WHERE idkategori=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def updateByID(self, id):
        self.conn = mydb()
        val = (self.__idkategori, self.__nama_kategori, id)
        sql="UPDATE kategori SET idkategori=%s, nama_kategori=%s WHERE idkategori=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def delete(self, id):
        self.conn = mydb()
        sql="DELETE FROM kategori WHERE idkategori='" + str(id) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def deleteByID(self, id):
        self.conn = mydb()
        sql="DELETE FROM kategori WHERE idkategori='" + str(id) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def getByIDS(self, id):
        self.conn = mydb()
        sql="SELECT * FROM kategori WHERE idkategori='" + str(id) + "'"
        self.result = self.conn.findOne(sql)                   
        self.__idkategori = self.result[0]
        self.__nama_kategori = self.result[1]  
        self.conn.disconnect
        return self.result
        
    def getByID(self, id):
        a=str(id)
        b=a.strip()
        self.conn = mydb()
        sql="SELECT * FROM kategori WHERE idkategori='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__idkategori = self.result[0]
            self.__nama_kategori = self.result[1]
            self.affected = self.conn.cursor.rowcount
        else:                  
            self.__nama_kategori = ''
            self.__idkategori = ''                  
            self.affected = 0
        self.conn.disconnect
        return self.result

    def getAllData(self):
        self.conn = mydb()
        sql="SELECT * FROM kategori"
        self.result = self.conn.findAll(sql)
        return self.result

a=Kategori()
b=a.getAllData()
print (b)
