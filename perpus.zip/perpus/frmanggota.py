import email
import os, sys; sys.path.insert(0,os.path.dirname(os.path.realpath(__name__)))
import sys
import mysql.connector as mc
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtWidgets import QMessageBox
from Anggota import Anggota

qtcreator_file  = "Anggota.ui" # Enter file here.
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)


class AnggotaWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)

        # Event Setup
        self.btnCari.clicked.connect(self.search_data) # Jika tombol cari diklik
        self.btnSimpan.clicked.connect(self.save_data) # Jika tombol simpan diklik
        self.Kode.returnPressed.connect(self.search_data) # Jika menekan tombol Enter saat berada di textbox kode
        self.btnClear.clicked.connect(self.clear_entry)
        self.btnHapus.clicked.connect(self.delete_data)
        self.edit_mode=""   
        self.btnHapus.setEnabled(False) # Matikan tombol hapus
        self.btnHapus.setStyleSheet("color:black;background-color : grey")

    def select_data(self):
        try:
            ang = Anggota()

            # Get all 
            result = ang.getAllData()

            self.gridAnggota.setHorizontalHeaderLabels(['ID', 'Kode Anggota', 'Nama', 'Jenis Kelamin', 'Keterangan'])
            self.gridAnggota.setRowCount(0)
            

            for row_number, row_data in enumerate(result):
                #print(row_number)
                self.gridAnggota.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    #print(column_number)
                    self.gridAnggota.setItem(row_number, column_number, QTableWidgetItem(str(data)))
        
        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def search_data(self):
        try:           
            kode=self.Kode.text()           
            ang = Anggota()

            # search process
            result = ang.getByKODE_ANGGOTA(kode)
            a = ang.affected
            if(a>0):
                self.TampilData(result)
            else:
                self.messagebox("INFO", "Data tidak ditemukan")
                self.Kode.setFocus()
                self.btnSimpan.setText("Simpan")
                self.edit_mode=False
                self.btnHapus.setEnabled(False) # Matikan tombol hapus
                self.btnHapus.setStyleSheet("color:black;background-color : grey")
            
        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def save_data(self, MainWindow):
        try:
            ang = Anggota()
            kode=self.Kode.text()
            nama=self.Nama.text()
            if self.Laki.isChecked():
                jk="L"
            
            if self.Perempuan.isChecked():
                jk="P"

            email=self.email.text()
            tlp=self.telpon.text()
            
            if(self.edit_mode==False):  
                ang.kode_anggota = kode 
                ang.nama = nama
                ang.jk = jk
                ang.email = email
                ang.telpon = tlp
                a = ang.simpan()
                if(a>0):
                    self.messagebox("SUKSES", "Data Anggota Tersimpan")
                else:
                    self.messagebox("GAGAL", "Data Anggota Gagal Tersimpan")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            elif(self.edit_mode==True):
                ang.kode_anggota = kode
                ang.nama = nama
                ang.jk = jk
                ang.email = email
                ang.telpon = tlp
                a = ang.updateByKODE_ANGGOTA(kode)
                if(a>0):
                    self.messagebox("SUKSES", "Data Anggota Diperbarui")
                else:
                    self.messagebox("GAGAL", "Data Anggota Gagal Diperbarui")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            else:
                self.messagebox("ERROR", "Terjadi kesalahan Mode Edit")
            

        except mc.Error as e:
            self.messagebox("ERROR", str(e))

    def delete_data(self, MainWindow):
        try:
            ang = Anggota()
            kode=self.Kode.text()
                       
            if(self.edit_mode==True):
                a = ang.deleteByKODE_ANGGOTA(kode)
                if(a>0):
                    self.messagebox("SUKSES", "Data Anggota Dihapus")
                else:
                    self.messagebox("GAGAL", "Data Anggota Gagal Dihapus")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            else:
                self.messagebox("ERROR", "Sebelum meghapus data harus ditemukan dulu")
            

        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def TampilData(self,result):
        self.Kode.setText(result[1])
        self.Nama.setText(result[2])
        if(result[3]=="L"):
            self.Laki.setChecked(True)
            self.Perempuan.setChecked(False)
        else:
            self.Laki.setChecked(False)
            self.Perempuan.setChecked(True)

        self.email.setText(result[4])
        self.telpon.setText(result[5])
        self.btnSimpan.setText("Update")
        self.edit_mode=True
        self.btnHapus.setEnabled(True) # Aktifkan tombol hapus
        self.btnHapus.setStyleSheet("background-color : red")

    def clear_entry(self, MainWindow):
        self.Kode.setText("")
        self.Nama.setText("")
        self.Laki.setChecked(False)
        self.Perempuan.setChecked(False)
        self.email.setText("")
        self.telpon.setText("")
        self.btnHapus.setEnabled(False) # Matikan tombol hapus
        self.btnHapus.setStyleSheet("color:black;background-color : grey")

    def messagebox(self, title, message):
        mess = QMessageBox()
        mess.setWindowTitle(title)
        mess.setText(message)
        mess.setStandardButtons(QMessageBox.Ok)
        mess.exec_()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = AnggotaWindow()
    window.show()
    window.select_data()
    sys.exit(app.exec_())
else:
    app = QtWidgets.QApplication(sys.argv)
    window = AnggotaWindow()