import os, sys; sys.path.insert(0,os.path.dirname(os.path.realpath(__name__)))
import sys
from PyQt5 import QtWidgets, uic
import psycopg2 as mc
from PyQt5.QtWidgets import QTableWidgetItem
from PyQt5.QtWidgets import QMessageBox
from Buku import Buku

qtcreator_file  = "Buku.ui" # Enter file here.
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)


class BukuWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)

        # Event Setup
        self.btnCari.clicked.connect(self.search_data) # Jika tombol cari diklik
        self.btnSimpan.clicked.connect(self.save_data) # Jika tombol simpan diklik
        self.Kode.returnPressed.connect(self.search_data) # Jika menekan tombol Enter saat berada di textbox nama
        self.btnClear.clicked.connect(self.clear_entry)
        self.btnHapus.clicked.connect(self.delete_data)
        self.edit_mode=""   
        self.btnHapus.setEnabled(False) # Matikan tombol hapus
        self.btnHapus.setStyleSheet("color:black;background-color : grey")

    def select_data(self):
        try:
            bks = Buku()

            # Get all 
            result = bks.getAllData()

            self.gridBuku.setHorizontalHeaderLabels(['ID Buku', 'Kode Buku', 'Id Kategori', 'Judul Buku', 'Pengarang', 'Penerbit', 'Tahun Terbit'])
            self.gridBuku.setRowCount(0)
            

            for row_number, row_data in enumerate(result):
                #print(row_number)
                self.gridBuku.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    #print(column_number)
                    self.gridBuku.setItem(row_number, column_number, QTableWidgetItem(str(data)))
        
        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def search_data(self):
        try:           
            kd=self.Kode.text()           
            bks = Buku()

            # search process
            result = bks.getByKODE_BUKU(kd)
            a = bks.affected
            if(a>0):
                self.TampilData(result)
            else:
                self.messagebox("INFO", "Data tidak ditemukan")
                self.Kode.setFocus()
                self.btnSimpan.setText("Simpan")
                self.edit_mode=False
                self.btnHapus.setEnabled(False) # Matikan tombol hapus
                self.btnHapus.setStyleSheet("color:black;background-color : grey")
            
        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def save_data(self, MainWindow):
        try:
            bks = Buku()
            kd = self.Kode.text()
            jd= self.Judul.text()
            kg= self.Kategori.text()
            pn= self.Penulis.text()
            pb= self.Penerbit.text()
            tn= self.Tahun.text()
            if(self.edit_mode==False):  
                bks.kode_buku = kd 
                bks.judul = jd
                bks.idkategori = kg
                bks.pengarang = pn
                bks.idpenerbit = pb
                bks.tahun = tn
                a = bks.simpan()
                if(a>0):
                    self.messagebox("SUKSES", "Data Buku Tersimpan")
                else:
                    self.messagebox("GAGAL", "Data Buku Gagal Tersimpan")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            elif(self.edit_mode==True):
                bks.kode_buku = kd 
                bks.judul = jd
                bks.idkategori = kg
                bks.pengarang = pn
                bks.idpenerbit = pb
                bks.tahun = tn
                a = bks.updateByKODE_BUKU(kd)
                if(a>0):
                    self.messagebox("SUKSES", "Data Buku Diperbarui")
                else:
                    self.messagebox("GAGAL", "Data Buku Gagal Diperbarui")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            else:
                self.messagebox("ERROR", "Terjadi kesalahan Mode Edit")
            

        except mc.Error as e:
            self.messagebox("ERROR", str(e))

    def delete_data(self, MainWindow):
        try:
            bks = Buku()
            kd=self.Kode.text()
                       
            if(self.edit_mode==True):
                a = bks.deleteByKODE_BUKU(kd)
                if(a>0):
                    self.messagebox("SUKSES", "Data Buku Dihapus")
                else:
                    self.messagebox("GAGAL", "Data Buku Gagal Dihapus")
                
                self.clear_entry(self) # Clear Entry Form
                self.select_data() # Reload Datagrid
            else:
                self.messagebox("ERROR", "Sebelum meghapus data harus ditemukan dulu")
            

        except mc.Error as e:
            self.messagebox("ERROR", "Terjadi kesalahan koneksi data")

    def TampilData(self,result):
        self.Kode.setText(str(result[1]))
        self.Judul.setText(str(result[3]))
        self.Kategori.setText(str(result[2]))
        self.Penulis.setText(str(result[4]))
        self.Penerbit.setText(str(result[5]))
        self.Tahun.setText(str(result[6]))
        self.btnSimpan.setText("Update")
        self.edit_mode=True
        self.btnHapus.setEnabled(True) # Aktifkan tombol hapus
        self.btnHapus.setStyleSheet("background-color : red")

    def clear_entry(self, MainWindow):
        self.Kode.setText("")
        self.Judul.setText("")
        self.Kategori.setText("")
        self.Penulis.setText("")
        self.Penerbit.setText("")
        self.Tahun.setText("")
        self.btnHapus.setEnabled(False) # Matikan tombol hapus
        self.btnHapus.setStyleSheet("color:black;background-color : grey")

    def messagebox(self, title, message):
        mess = QMessageBox()
        mess.setWindowTitle(title)
        mess.setText(message)
        mess.setStandardButtons(QMessageBox.Ok)
        mess.exec_()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = BukuWindow()
    window.show()
    window.select_data()
    sys.exit(app.exec_())
else:
    app = QtWidgets.QApplication(sys.argv)
    window = BukuWindow()
