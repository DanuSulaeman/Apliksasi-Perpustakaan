
import sys
from PyQt5 import QtWidgets, QtCore, uic
import mysql.connector as mc
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QTableWidgetItem
from frmanggota import AnggotaWindow
from frmbuku import BukuWindow
from frmkategori import KategoriWindow
from frmPeminjaman import WindowPeminjaman
# <library> #

qtcreator_file  = "Dasboard.ui" # File Design Tampilan Dashboard
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)

class WindowDasboard(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)     
        # Event Setup
        self.actionExit.triggered.connect(self.app_exit) # ketika klik menu Exit
        self.actionAnggota.triggered.connect(self.app_anggota)
        self.actionBuku.triggered.connect(self.app_buku)
        self.actionPeminjaman.triggered.connect(self.app_peminjaman)
        self.actionKategori.triggered.connect(self.app_kategori)
        # <click-action> #      

    def app_exit(self):
        sys.exit()

    def app_anggota(self):
        winAnggota.setWindowModality(QtCore.Qt.ApplicationModal)
        winAnggota.show()

    def app_peminjaman(self):
        winPeminjaman.setWindowModality(QtCore.Qt.ApplicationModal)
        winPeminjaman.show()   

    def app_buku(self):
        winBuku.setWindowModality(QtCore.Qt.ApplicationModal)
        winBuku.show()

    def app_kategori(self):
        winKategori.setWindowModality(QtCore.Qt.ApplicationModal)
        winKategori.show()

    # <def action> #

    def messagebox(self, title, message):
        mess = QMessageBox()
        mess.setWindowTitle(title)
        mess.setText(message)
        mess.setStandardButtons(QMessageBox.Ok)
        mess.exec_()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = WindowDasboard() # load object window dashboard
    winPeminjaman = WindowPeminjaman()
    winAnggota = AnggotaWindow()
    winKategori = KategoriWindow()
    winBuku = BukuWindow()

    # <load-object> #
    window.showFullScreen() # Tampilkan window dashboard
    sys.exit(app.exec_())

else:
    app = QtWidgets.QApplication(sys.argv)
    window = WindowDasboard() # load object window login
    winPeminjaman = WindowPeminjaman()
    winAnggota = AnggotaWindow()
    winKategori = KategoriWindow()
    winBuku = BukuWindow()    
    