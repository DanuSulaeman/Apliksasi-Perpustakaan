from db import DBConnection as mydb
class Penerbit:
    def __init__(self):
        self.__idpernerbit= None
        self.__nama_penerbit= None
        self.__kota= None
        self.__issn= None
        self.__info = None
        self.conn = None
        self.affected = None
        self.result = None
    
    @property
    def idpernerbit(self):
        return self.__idpernerbit
    
    @property
    def nama_penerbit(self):
        return self.__nama_penerbit

    @nama_penerbit.setter
    def nim(self, value):
        self.__nama_penerbit = value

    @property
    def kota(self):
        return self.__kota

    @kota.setter
    def nim(self, value):
        self.__kota = value

    @property
    def issn(self):
        return self.__issn

    @issn.setter
    def nim(self, value):
        self.__issn = value
        
    def simpan(self):
        self.conn = mydb()
        val = (self.__nama_penerbit, self.__kota, self.__issn)
        sql="INSERT INTO penerbit (nama_penerbit, kota, issn) VALUES " + str(val) 
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
        
    def update(self, id):
        self.conn = mydb()
        val = (self.__nama_penerbit, self.__kota, self.__issn, id)
        sql="UPDATE buku SET nama_penerbit=%s, kota=%s, issn=%s WHERE idkategori=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def updateByNama(self, nama_penerbit):
        self.conn = mydb()
        val = (self.__kota, self.__issn, nama_penerbit)
        sql="UPDATE penerbit SET kota=%s, issn=%s WHERE nama_kategori=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def delete(self, id):
        self.conn = mydb()
        sql="DELETE FROM penerbit WHERE idpenerbit='" + str(id) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def deleteByNama(self, nama_penerbit):
        self.conn = mydb()
        sql="DELETE FROM penerbit WHERE nama_penerbit='" + str(nama_penerbit) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def getByID(self, id):
        self.conn = mydb()
        sql="SELECT * FROM penerbit WHERE idpenerbit='" + str(id) + "'"
        self.result = self.conn.findOne(sql)                   
        self.__nama_penerbit = self.result[1]                   
        self.conn.disconnect
        return self.result
        
    def getByNama(self, nama_penerbit):
        a=str(nama_penerbit)
        b=a.strip()
        self.conn = mydb()
        sql="SELECT * FROM penerbit WHERE nama_penerbit='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__nama_penerbit = self.result[1]
            self.affected = self.conn.cursor.rowcount
        else:                  
            self.__nama_penerbit = ''                  
            self.affected = 0
        self.conn.disconnect
        return self.result

    def getAllData(self):
        self.conn = mydb()
        sql="SELECT * FROM penerbit"
        self.result = self.conn.findAll(sql)
        return self.result

a=Penerbit()
b=a.getAllData()
print (b)
